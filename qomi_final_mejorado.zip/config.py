class Config:
    DEBUG = True
