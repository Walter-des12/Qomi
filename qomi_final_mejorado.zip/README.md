# QOMI App con Navbar

Incluye login, menú dinámico, pasarela de pago, notificación y navegación superior.