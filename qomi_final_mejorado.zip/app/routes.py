
from flask import Blueprint, render_template, request, redirect, url_for, session

main = Blueprint('main', __name__)

@main.route('/')
def login():
    session['usuario'] = 'walter'
    session['carrito'] = []
    return render_template('login.html')

@main.route('/register')
def register():
    return render_template('register.html')

@main.route('/cafeteria', methods=['POST', 'GET'])
def cafeteria():
    return render_template('select_cafeteria.html')

@main.route('/menu', methods=['POST', 'GET'])
def menu():
    cafeteria = request.form.get('cafeteria') or 'Café Bio'
    return render_template('menu.html', cafeteria=cafeteria)

@main.route('/addcarrito', methods=['POST'])
def addcarrito():
    plato = request.form.get('plato')
    if 'carrito' not in session:
        session['carrito'] = []
    session['carrito'].append(plato)
    session.modified = True
    return redirect(url_for('main.carrito'))

@main.route('/carrito')
def carrito():
    return render_template('carrito.html', carrito=session.get('carrito', []))

@main.route('/vaciar', methods=['POST'])
def vaciar():
    session['carrito'] = []
    return redirect(url_for('main.carrito'))

@main.route('/reserva', methods=['POST'])
def reserva():
    data = request.form
    return render_template('reserva.html', cafeteria=data.get('cafeteria'),
                           hora=data.get('hora'),
                           entrada=data.get('entrada'),
                           fondo=data.get('fondo'),
                           bebida=data.get('bebida'))

@main.route('/pago', methods=['POST'])
def pago():
    return render_template('pago.html', **request.form)

@main.route('/confirmacion', methods=['POST'])
def confirmacion():
    return render_template('confirmacion.html', **request.form)

@main.route('/notificacion')
def notificacion():
    return render_template('notificacion.html')

@main.route('/despedida')
def despedida():
    return render_template('despedida.html')

@main.route('/micuenta')
def micuenta():
    return render_template('micuenta.html', usuario=session.get('usuario', 'Usuario'))

@main.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.login'))
