from flask import Flask

def create_app():
    app = Flask(__name__)
    app.secret_key = 'qomi_super_secret_2025'  # Clave secreta necesaria para usar session

    from .routes import main
    app.register_blueprint(main)

    return app
